namespace NeuraAPI
{
    public enum VelocityStates
    {
    	Attaching,
    	Attached,
    	NotAttached,
    	NoProcessFound,
    	TamperDetected,
    	Error,
    	Executed
    }
}
