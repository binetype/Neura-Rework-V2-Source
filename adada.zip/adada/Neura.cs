﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using System.Timers;
using coms;

namespace NeuraAPI
{
    public class Neura
    {
    	private HttpClient client = new HttpClient();

        private string current_injector_url = "https://getvelocity.lol/assets/erto3e4rortoergn.exe";

        private string currret_decompiler_url = "https://getvelocity.lol/assets/Decompiler.exe";

        private string current_version_url = "https://getvelocity.lol/assets/current_version.txt";

        private Process decompilerProcess;

    	public VelocityStates VelocityStatus = VelocityStates.NotAttached;

    	public List<int> injected_pids = new List<int>();

    	private Timer CommunicationTimer;

    	public static string Base64Encode(string plainText)
    	{
    		return Convert.ToBase64String(Encoding.UTF8.GetBytes(plainText));
    	}

    	public static byte[] Base64Decode(string plainText)
    	{
    		return Convert.FromBase64String(plainText);
    	}

    	private bool IsPidRunning(int pid)
    	{
    		try
    		{
    			Process.GetProcessById(pid);
    			return true;
    		}
    		catch (ArgumentException)
    		{
    			return false;
    		}
    	}

        public static void RestartRoblox()
        {

            var processes = Process.GetProcessesByName("RobloxPlayerBeta");
            foreach (var process in processes)
            {
                try
                {
                    process.Kill();
                    process.WaitForExit(); 
                }
                catch (Exception)
                {

                }
            }


            try
            {

                string robloxPath = Path.Combine(
                    Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
                    @"Roblox\Versions");

                if (Directory.Exists(robloxPath))
                {

                    var latestVersionDir = new DirectoryInfo(robloxPath)
                        .GetDirectories()
                        .OrderByDescending(d => d.LastWriteTime)
                        .FirstOrDefault();

                    if (latestVersionDir != null)
                    {
                        string exePath = Path.Combine(latestVersionDir.FullName, "RobloxPlayerBeta.exe");
                        if (File.Exists(exePath))
                        {
                            Process.Start(exePath);
                        }
                        else
                        {
                            Console.WriteLine("RobloxPlayerBeta.exe not found in the latest version folder.");
                        }
                    }
                    else
                    {
                        Console.WriteLine("No Roblox version directories found.");
                    }
                }
                else
                {
                    Console.WriteLine("Roblox installation path not found.");
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error restarting Roblox: " + ex.Message);
            }
        }

        public static void KillRoblox()
        {
            var processes = Process.GetProcessesByName("RobloxPlayerBeta")
                            .Concat(Process.GetProcessesByName("eurotruck2"));
            foreach (var process in processes)
            {
                try
                {
                    process.Kill();

                }
                catch (Exception ex)
                {

                }
            }
        }

        private void AutoUpdate()
    	{
    		string text = "";
    		try
    		{
    			text = client.GetStringAsync(current_version_url).Result;
    		}
    		catch (Exception)
    		{
    			return;
    		}
    		string text2 = "";
    		if (File.Exists("Bin\\current_version.txt"))
    		{
    			text2 = File.ReadAllText("Bin\\current_version.txt");
    		}
    		if (text != text2)
    		{
    			if (File.Exists("Bin\\erto3e4rortoergn.exe"))
    			{
    				File.Delete("Bin\\erto3e4rortoergn.exe");
    			}
    			if (File.Exists("Bin\\Decompiler.exe"))
    			{
    				File.Delete("Bin\\Decompiler.exe");
    			}
    			HttpResponseMessage result = client.GetAsync(current_injector_url).Result;
    			if (result.IsSuccessStatusCode)
    			{
    				byte[] result2 = result.Content.ReadAsByteArrayAsync().Result;
    				File.WriteAllBytes("Bin\\erto3e4rortoergn.exe", result2);
    			}
    			HttpResponseMessage result3 = client.GetAsync(currret_decompiler_url).Result;
    			if (result3.IsSuccessStatusCode)
    			{
    				byte[] result4 = result3.Content.ReadAsByteArrayAsync().Result;
    				File.WriteAllBytes("Bin\\Decompiler.exe", result4);
    			}
    		}
    		File.WriteAllText("Bin\\current_version.txt", text);
    	}

        public void StartCommunication()
        {
            if (!Directory.Exists("Bin"))
            {
                Directory.CreateDirectory("Bin");
            }
            if (!Directory.Exists("AutoExec"))
            {
                Directory.CreateDirectory("AutoExec");
            }
            if (!Directory.Exists("Workspace"))
            {
                Directory.CreateDirectory("Workspace");
            }
            if (!Directory.Exists("Scripts"))
            {
                Directory.CreateDirectory("Scripts");
            }
            this.AutoUpdate();
            this.StopCommunication();
            this.decompilerProcess = new Process();
            this.decompilerProcess.StartInfo.FileName = "Bin\\Decompiler.exe";
            this.decompilerProcess.StartInfo.UseShellExecute = false;
            this.decompilerProcess.EnableRaisingEvents = true;
            this.decompilerProcess.StartInfo.RedirectStandardError = true;
            this.decompilerProcess.StartInfo.RedirectStandardInput = true;
            this.decompilerProcess.StartInfo.RedirectStandardOutput = true;
            this.decompilerProcess.StartInfo.CreateNoWindow = true;
            this.decompilerProcess.Start();
            this.CommunicationTimer = new Timer(100.0);
            this.CommunicationTimer.Elapsed += delegate (object source, ElapsedEventArgs e)
            {
                foreach (int num in this.injected_pids)
                {
                    if (!this.IsPidRunning(num))
                    {
                        this.injected_pids.Remove(num);
                    }
                }
                string plainText = "setworkspacefolder: " + Directory.GetCurrentDirectory() + "\\Workspace";
                foreach (int pid in this.injected_pids)
                {
                    NamedPipes.LuaPipe(Neura.Base64Encode(plainText), pid);
                }
            };
            this.CommunicationTimer.Start();
        }


        public void StopCommunication()
    	{
    		if (CommunicationTimer != null)
    		{
    			CommunicationTimer.Stop();
    			CommunicationTimer = null;
    		}
    		if (decompilerProcess != null)
    		{
    			decompilerProcess.Kill();
    			decompilerProcess.Dispose();
    			decompilerProcess = null;
    		}
    		injected_pids.Clear();
    	}

        public bool IsAttached(int pid)
    	{
    		return injected_pids.Contains(pid);
    	}
        

        public async Task<VelocityStates> Attach(int pid)
        {
            if (injected_pids.Contains(pid))
            {
                return VelocityStates.Attached;
            }

            VelocityStatus = VelocityStates.Attaching;

            await Task.Run(() =>
            {
           Process.Start(new ProcessStartInfo
                {
                    FileName = "Bin\\erto3e4rortoergn.exe",
                    Arguments = $"{pid}",
                    CreateNoWindow = false,
                    UseShellExecute = false,
                    RedirectStandardError = false,
                    RedirectStandardOutput = false
                }).WaitForExit();
            });

            injected_pids.Add(pid);
            VelocityStatus = VelocityStates.Attached;

            await Task.Delay(3000);

            string script = @"loadstring(game:HttpGet('https://raw.githubusercontent.com/CreditzKed/CzkInjectText/refs/heads/main/Injected2.Lua'))()";
            Execute(script);
            string BUTTCHEEECKS = @"print(""😍Neura..."")
wait(2)
print(""💕Neura......"")
wait(2)
print(""👌Neura..........."")
wait(2)

-- Saturn-style ASCII art
print([[
_____====_____
           ,-:` \;',`'-, 
         .'-;_,;  ':-;_,'.
        /;   '/    ,  _`.-\
       | '`. (`     /` ` \`|
       |:.  `\`-.   \_   / |
       |     (   `,  .` |
        \     | .'     /
         `-.  \     .-'
            `-.`.__.'
              /   \
             /     \
            ( NEURA )
]])

wait(1)
print(""CONNECTED NEURA EXECUTOR❤️"")
print("" Running "")
";
            Execute(BUTTCHEEECKS);

            return VelocityStates.Attached;
        }

        public VelocityStates Execute(string script)
    	{
    		if (injected_pids.Count.Equals(0))
    		{
    			return VelocityStates.NotAttached;
    		}
    		foreach (int injected_pid in injected_pids)
    		{
    			NamedPipes.LuaPipe(Base64Encode(script), injected_pid);
    		}
    		return VelocityStates.Executed;
    	}
    }
}
